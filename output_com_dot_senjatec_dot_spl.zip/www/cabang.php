<style>
  /* Always set the map height explicitly to define the size of the div
   * element that contains the map. */
  #map {
    height: 100%;
  }
  /* Optional: Makes the sample page fill the window. */
  html, body {
    height: 100%;
    margin: 0;
    padding: 0;
  }
</style>
<?php
//error_reporting(0);
// definisikan koneksi ke database
$server = "localhost";
$username = "splcargo_db";
$password = "splcargo_db!";
$database = "splcargo_db";

// Koneksi dan memilih database di server
mysql_connect($server,$username,$password) or die("Koneksi gagal");
mysql_select_db($database) or die("Database tidak bisa dibuka");



?>
<div id="map"></div>
<script>
var locations = [
<?php 
$no=1;
$data=mysql_query("SELECT kota,la,lo FROM ap_cabang");
while($r=mysql_fetch_array($data)){
?>    
  ['<?php echo $r[kota] ?>', <?php echo $r[la] ?>,<?php echo $r[lo] ?>, <?php echo $no ?>],
<?php $no++; } ?>
];

function initMap() {
  var myLatLng = {lat: -3.698324, lng: 108.8787931};

  var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 5,
    center: myLatLng
    });

  var count;

  for (count = 0; count < locations.length; count++) {  
    new google.maps.Marker({
      position: new google.maps.LatLng(locations[count][1], locations[count][2]),
      map: map,
      title: locations[count][0]
      });
   }
}
</script>
<script async defer
src="https://maps.googleapis.com/maps/api/js?key=
AIzaSyAZbBhRvkXydUENXvyLEXhw8sONVT7Egvc
&callback=initMap">
</script>