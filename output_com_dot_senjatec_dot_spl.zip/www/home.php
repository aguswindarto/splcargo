<!DOCTYPE HTML>
	<link rel="stylesheet" type="text/css" href="../beta/css/responsive.css" media="all"/>
		<link rel="stylesheet" type="text/css" href="../beta/css/framework.css" media="all"/>
<?php
//error_reporting(0);
// definisikan koneksi ke database
$server = "localhost";
$username = "splcargo_db";
$password = "splcargo_db!";
$database = "splcargo_db";

// Koneksi dan memilih database di server
mysql_connect($server,$username,$password) or die("Koneksi gagal");
mysql_select_db($database) or die("Database tidak bisa dibuka");
$front=mysql_fetch_array(mysql_query("SELECT * FROM ap_front where id_front='1'"));

?>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"
			  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
			  crossorigin="anonymous"></script>
			  
    <script>
 

    $(function() {  
        $( "#awal" ).autocomplete({
         source: "datakotaawal.php",  
           minLength:2, 
        });
    });

    $(function() {  
        $( "#akhir" ).autocomplete({
         source: "datakotaawal.php",  
           minLength:2, 
        });
    });    
    </script>			  
<style>

    
#slider {
  position: relative;
  overflow: hidden;
  margin: 20px auto 0 auto;
  border-radius: 4px;
}

#slider ul {
  position: relative;
  margin: 0;
  padding: 0;
  height: 200px;
  list-style: none;
}

#slider ul li {
  position: relative;
  display: block;
  float: left;
  margin: 0;
  padding: 0;
  width: 300px;
  height: 200px;
  background: transparent;
  text-align: center;
  line-height: 300px;
}

a.control_prev, a.control_next {
  position: absolute;
  top: 40%;
  z-index: 999;
  display: block;
  padding: 4% 3%;
  width: auto;
  height: auto;
  background: transparent;
  color: #fff;
  text-decoration: none;
  font-weight: 600;
  font-size: 18px;
  opacity: 0.8;
  cursor: pointer;
}

a.control_prev:hover, a.control_next:hover {
  opacity: 1;
  -webkit-transition: all 0.2s ease;
}

a.control_prev {
  border-radius: 0 2px 2px 0;
}

a.control_next {
  right: 0;
  border-radius: 2px 0 0 2px;
}

.slider_option {
  position: relative;
  margin: 10px auto;
  width: 160px;
  font-size: 18px;
}

</style>
<script>
function target_popup(form) {
    window.open('poptrack.php', 'formpopup', 'width=500,height=650,resizeable,scrollbars');
    form.target = 'formpopup';
}    

function target_popup2(form) {
    window.open('poptrack.php', 'formpopup', 'width=1024,height=650,resizeable,scrollbars');
    form.target = 'formpopup';
}  

</script>

		<div class="container">
			<div class="list-adv5">
				<div class="row">
				   <marquee><b>NEWS: <?php echo $front[news] ?></b></marquee> 
				</div>
			</div>
		</div>
		<div class="container">
			<div class="list-adv5">
				<div class="row">
					<div class="col-md-4 col-sm-4 col-xs-12">
						<div class="item-adv5 text-center">
							<div class="adv-info5">
								<h3 class="title24"><a href="#" class="silver"><font color=white>Tarif</font></a></h3>
									&nbsp;	<img src=rupiah.png width=25px> <br>
								<h3 class="title14"><b>CEK TARIF</b></h3>
							<form methode=GET onsubmit="target_popup(this)" action=poptarif.php>
								<center><table width=100%>
			<tr><td align=left style="padding-bottom:20px;";><b>Asal <b></td><td align=left >: <input type=text name=awal placeholder="Origin" class="navi border" style="width:200px;height:30px;text-transform:uppercase;border-color:black;"id=awal></td></tr>
			<tr><td align=left style="padding-bottom:20px;";><b>Tujuan </b></td><td align=left>: <input type=text name=akhir placeholder="Destination" class="navi border" style="width:200px;height:30px;text-transform:uppercase;border-color:black;" id=akhir > </td></tr>
			<tr><td align=left><b>Berat </b></td><td align=left>: <input type=text name=berat placeholder="Kg" class="navi border" size="10" style="width:80px;height:30px;text-transform:uppercase;border-color:black;"></td></tr>
			<!--
			<tr><td align=left>Dimensi </td><td align=left>: <input type=text name=awal placeholder="P" class="navi border" size="3" style="width:80px;"> <font color=white>x</font> <input type=text name=awal placeholder="L" class="navi border" size="3" style="width:70px;"> <font color=white>x</font> <input type=text name=awal placeholder="T" class="navi border" size="3" style="width:70px;"></td></tr> -->
			</table></center><font style="font-size:12px">Silahkan Cek Tarif</font><br>
			<input type=submit value=Cek style="background-color: red;border-radius: 3px;border:0px;font-size:16px;color:white">	
			<br></form>
							</div>
				
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12">
						<div class="item-adv5 text-center">
						    <form methode=GET onsubmit="target_popup2(this)" action=http://splcargo.co.id/beta/lacak/>
							<div class="adv-info5">
								<h3 class="title24"><a href="#" class="silver"><font color=white>Tracking</font></a></h3>
								&nbsp;	<img src=cari.png width=25px> <br>
								<h3 class="title14"><b>LACAK STATUS PENGIRIMAN</b></h3>
								
							<center>
			<textarea class="navi border" name=awb style="width:100%;height:100px"></textarea>
		<font style="font-size:12px;family:arial;">	Masukan Nomer AWB/ STT max 5</font><br>
			<input type=submit value=Track  style="background-color: red;border-radius: 3px;border:0px;font-size:16px;color:white">
<center>
												</div>
</form>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12">
					    <form methode=GET onsubmit="target_popup(this)" action=poplokasi.php>
					<div class="item-adv5 text-center">
							<div class="adv-info5">
								<h3 class="title24"><a href="#" class="silver"><font color=white>Lokasi</font></a></h3>
									&nbsp;	<img src=map.png width=25px> <br>
								<h3 class="title14"><b>CEK ALAMAT CABANG</b></h3>
							
							<center>
			<textarea class="navi border" name=lokasi style="width:100%;height:100px"></textarea>
			<br><font style="font-size:12px;family:tahoma">Silahkan masukan alamat cabang terdekat </font><br>
			<input type=submit value=Cari  style="background-color: red;border-radius: 3px;border:0px;font-size:16px;color:white">
<center>
												</div>

						</div>
						</form>
					</div>
				</div>
			</div>
			<!-- End Adv -->
		</div>

				<div class="container">
					<div class="row">
						<div class="col-md-4 col-sm-4 col-s-12">
						<div class="why-choise5">
							<h2 class="title30 ">Informasi</h2>
							<div class="row">

								<div class="col-md-12 col-sm-12 col-xs-12">
								<br>
									<div class="service-footer6">
									<?php echo "$front[informasi]"; ?>	
									</div>
								</div>
							</div>
						</div>
						</div>
						<div class="col-md-4 col-sm-4 col-s-12">
							<div class="footer-block6">
								<h2 class="title30">&nbsp;</h2>
								<div class="service-footer6">
<?php echo "$front[youtube]"; ?>								
								</div>
							</div>
						</div>
						<div class="col-md-4 col-sm-4 col-s-12">
							<div class="footer-block6">
								<h2 class="title30 ">Gallery Photo</h2>
<div id="slider">

  <ul>

<?php
//error_reporting(0);
// definisikan koneksi ke database
$server = "localhost";
$username = "splcargo_db";
$password = "splcargo_db!";
$database = "splcargo_db";

// Koneksi dan memilih database di server
mysql_connect($server,$username,$password) or die("Koneksi gagal");
mysql_select_db($database) or die("Database tidak bisa dibuka");


            $tampils=mysql_query("SELECT * FROM ap_slide order by rand()");
            while($sl=mysql_fetch_array($tampils)){
               echo "<li><img width=340px height=300px src=http://office.splcargo.co.id/public/uploads/slide/$sl[gambar]></li>"; 
            }

?>
  </ul>  
</div>
<input type="hidden" id="checkbox" checked>

							</div>
						</div>
					</div>
				</div>	
		<hr>	
			<!-- End Banner -->
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-s-12">
			<div class="brand-box">
				<center><h2 class="title30 font-bold ">Partner kami</h2></center>
				<div class="brand-slider">
					<div class="wrap-item group-navi" data-pagination="false" data-autoplay="true" data-navigation="true" >
						<div class="item-brand text-center" >
							<a href="#" class="wobble-horizontal"><img src="brand/01.png" alt=""  /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/02.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/03.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/04.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/05.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/06.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/07.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/08.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/09.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/10.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/11.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/12.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/13.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/14.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/15.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/16.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/17.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/18.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/19.png" alt="" /></a>
						</div>		
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/20.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/21.png" alt="" /></a>
						</div>
						<div class="item-brand text-center">
							<a href="#" class="wobble-horizontal"><img src="brand/22.png" alt="" /></a>
						</div>
											
					</div>
				</div>
			</div>
			</div></div></div>
			<!-- End Brand -->				
				<hr>

		<div class="container">
			<div class="latest-news">
				<div class="latest-news-intro text-center">
					<h2 class="title30 font-bold">Berita Terbaru</h2>
					<a href="./?p=allblog" class="shop-button color">View All <i class="icon ion-android-arrow-forward"></i></a>
				</div>	
				<div class="list-latest-post">
					<div class="wrap-item" data-pagination="false" data-itemscustom="[[0,1],[560,2],[990,3]]">
					    
<?php
//error_reporting(0);
// definisikan koneksi ke database
$server = "localhost";
$username = "splcargo_db";
$password = "splcargo_db!";
$database = "splcargo_db";

// Koneksi dan memilih database di server
mysql_connect($server,$username,$password) or die("Koneksi gagal");
mysql_select_db($database) or die("Database tidak bisa dibuka");


            $tampilsb=mysql_query("SELECT * FROM ap_blog order by id_blog DESC LIMIT 3");
            while($b=mysql_fetch_array($tampilsb)){
             
       $cuplik=substr($b[isi], 0, 250)  ;
$cuplikj=substr($b[judul], 0, 50)  ;
?>					    
						<div class="item-post drop-shadow">
							<div class="banner-adv overlay-image zoom-image">
								<a href="#" class="adv-thumb-link"><img src="http://office.splcargo.co.id/public/uploads/blog/<?php echo $b[gambar]?>" alt="" /></a>
							</div>
							<div class="post-info">
								<h3 class="title18 font-bold"><a href="#"><?php echo $cuplikj ?> </a></h3>
								<span class="color post-date"><i class="icon ion-calendar"></i><?php echo $b[tgl]?></span>
								<p class="desc"><?php echo $cuplik ?></p>
								<a href="./?p=blog&id=<?php echo $b[id_blog]?>" class="shop-button color">Baca</a>
							</div>
						</div>
						
<?php } ?>

					</div>
				</div>
			</div>
			<!-- End Latest News -->
			

		</div>

				
<script src="../beta/js/libs/jquery-3.3.1.min.js"></script>
<script src="../beta/js/libs/bootstrap.min.js"></script>
<script src="../beta/js/libs/jquery.fancybox.min.js"></script>
<script src="../beta/js/libs/jquery-ui.min.js"></script>