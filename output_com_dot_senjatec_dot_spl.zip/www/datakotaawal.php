<?php
error_reporting(0);
//connect to your database
  mysql_connect("localhost","root","");
  mysql_select_db("splcargo");
//harus selalu gunakan variabel term saat memakai autocomplete,
//jika variable term tidak bisa, gunakan variabel q
$term = trim(strip_tags($_GET['term']));
 
$qstring = "SELECT id,name FROM regencies WHERE name LIKE '%$term%'";
//query database untuk mengecek tabel Country 
$result = mysql_query($qstring);
 
while ($row = mysql_fetch_array($result))
{
    $row['value']=htmlentities(stripslashes($row['name']));
  //  $row['id']=(int)$row['id'];
//buat array yang nantinya akan di konversi ke json
    $row_set[] = $row[1];
}
//data hasil query yang dikirim kembali dalam format json
echo json_encode($row_set);
?>