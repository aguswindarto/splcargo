<!DOCTYPE HTML><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0 minimal-ui"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black">

<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/splash/splash-icon.png">
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="images/splash/splash-icon-big.png">
<link rel="apple-touch-startup-image" href="images/splash/splash-screen.png" 	media="screen and (max-device-width: 320px)" />  
<link rel="apple-touch-startup-image" href="images/splash/splash-screen@2x.png" media="(max-device-width: 480px) and (-webkit-min-device-pixel-ratio: 2)" /> 
<link rel="apple-touch-startup-image" href="images/splash/splash-screen-six.png" media="(device-width: 375px)">
<link rel="apple-touch-startup-image" href="images/splash/splash-screen-six-plus.png" media="(device-width: 414px)">
<link rel="apple-touch-startup-image" sizes="640x1096" href="images/splash/splash-screen@3x.png" />
<link rel="apple-touch-startup-image" sizes="1024x748" href="images/splash/splash-screen-ipad-landscape" media="screen and (min-device-width : 481px) and (max-device-width : 1024px) and (orientation : landscape)" />
<link rel="apple-touch-startup-image" sizes="768x1004" href="images/splash/splash-screen-ipad-portrait.png" media="screen and (min-device-width : 481px) and (max-device-width : 1024px) and (orientation : portrait)" />
<link rel="apple-touch-startup-image" sizes="1536x2008" href="images/splash/splash-screen-ipad-portrait-retina.png"   media="(device-width: 768px)	and (orientation: portrait)	and (-webkit-device-pixel-ratio: 2)"/>
<link rel="apple-touch-startup-image" sizes="1496x2048" href="images/splash/splash-screen-ipad-landscape-retina.png"   media="(device-width: 768px)	and (orientation: landscape)	and (-webkit-device-pixel-ratio: 2)"/>

<title>SPL Cargo - Version 2.0</title>

<link href="styles/style.css"     		 rel="stylesheet" type="text/css">
<link href="styles/framework.css" 		 rel="stylesheet" type="text/css">
<link href="styles/owl.theme.css" 		 rel="stylesheet" type="text/css">
<link href="styles/swipebox.css"		 rel="stylesheet" type="text/css">
<link href="styles/font-awesome.css"	 rel="stylesheet" type="text/css">
<link href="styles/animate.css"			 rel="stylesheet" type="text/css">

<script type="text/javascript" src="scripts/jquery.js"></script>
<script type="text/javascript" src="scripts/jqueryui.js"></script>
<script type="text/javascript" src="scripts/framework.plugins.js"></script>
<script type="text/javascript" src="scripts/custom.js"></script>


</head>
<body> 

<div id="preloader">
	<div id="status">
    	<p class="center-text">
			Loading the content...
            <em>Loading depends on your connection speed!</em>
        </p>
    </div>
</div>
    
<div class="hide-content"></div>
<div class="all-elements">
    <div class="snap-drawers">
        <!-- Left Sidebar -->
        <div class="snap-drawer snap-drawer-left">
            <a href="index.html" class="selected-item"><i class="fa fa-home"></i>Home</a>
            <a href="tariff.html"><i class="fa fa-money"></i>Tariff</a>
            <a href="branch.html"><i class="fa fa-building-o"></i>Branch</a>
            <a href="profile.html"><i class="fa fa-user-md"></i>Profile</a>
            <a href="product.html"><i class="fa fa-th-large"></i>Product</a>
            <a href="client.html"><i class="fa fa-users"></i>ClientZone</a>
            <a href="contact.html"><i class="fa fa-comments-o"></i>CS</a>
            <a href="#" class="sidebar-close"><i class="fa fa-times"></i>Close</a>
        </div>
    </div>
    

    
    <a href="#" class="footer-ball"><i class="fa fa-navicon"></i></a>
    
    <!-- Page Content-->
    <div id="content" class="snap-content">        
      
         <br>
    
   <div class="content"> 
<?php
//error_reporting(0);
// definisikan koneksi ke database
$server = "localhost";
$username = "splcargo_db";
$password = "splcargo_db!";
$database = "splcargo_db";

// Koneksi dan memilih database di server
mysql_connect($server,$username,$password) or die("Koneksi gagal");
mysql_select_db($database) or die("Database tidak bisa dibuka");


if(!empty($_GET['awal']))
{
            $tampilv=mysql_query("SELECT * FROM ap_master where awb='$_POST[awb]' OR resi='$_POST[awb]' ");
            $rv=mysql_fetch_array($tampilv);
            
$a=mysql_fetch_array(mysql_query("SELECT * FROM regencies where id='$rv[kota_awal]' "));
$b=mysql_fetch_array(mysql_query("SELECT * FROM regencies where id='$rv[kota_akhir]' "));
$k=mysql_fetch_array(mysql_query("SELECT * FROM ap_kurir where id_kurir='$rv[id_kurir]' "));
 $s=mysql_fetch_array(mysql_query("SELECT * FROM ap_status where id_status='$rv[id_status]' "));   

            $jml=mysql_num_rows($tampilv);
           
  

    

?>
		<div class="container">
			<div class="content-pages">
				<div class="content-about content-contact-page">
					<h2 class="title30 font-bold text-uppercase">Tarif</h2><br>
					<?php echo $_GET[awal] ?> - <?php echo $_GET[akhir] ?>


					<!-- End Contact Info -->
					<div class="contact-form-faq">
						<div class="row">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="contact-form-page">
									<h2 class="title18 font-bold text-uppercase rale-font">Status</h2>
<table class="table table-bordered table-striped table-hover">
									<tbody><tr class="car_bold col_dark_bold" align="center">
						

										<td><font color="Black" face="arial,verdana"><strong>Service</strong></font></td>
										<td><font color="Black" face="arial,verdana"><strong>tarif</strong></font></td>
										<td><font color="Black" face="arial,verdana"><strong>Estimasi</strong></font></td>																							
									</tr>

									<tr align="center">
								
										<td>RS</td>
										<td>RP. 15.000</td>
										<td>3-4 hari</td>				
									
										</tr>

									<tr align="center">
								
										<td>NDS</td>
										<td>RP. 25.000</td>
										<td>3-4 hari</td>				
									
										</tr>

									<tr align="center">
								
										<td>SDS</td>
										<td>RP. 35.000</td>
										<td>31hari</td>				
									
										</tr>										
										</tbody></table>
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>

<?php 
    
} else{
    echo"<center><h3>ISI Kota Awal/Akhir DAHULU</h3></center>";
    echo '<meta http-equiv="refresh" content="1; url=tariff.html">';
}?>	            
             
  </div>

        <div class="footer">
            <p class="center-text">Copyright 2018. All rights reserved.</p>
            <div class="footer-socials half-bottom">
                <a href="#" class="footer-facebook"><i class="fa fa-facebook"></i></a>
                <a href="#" class="footer-twitter"><i class="fa fa-twitter"></i></a>
                <a href="#" class="footer-transparent"></a>
                <a href="#" class="footer-share show-share-bottom"><i class="fa fa-share-alt"></i></a>
                <a href="#" class="footer-up"><i class="fa fa-angle-up"></i></a>
            </div>
        </div>     
    </div>
    
    <div class="share-bottom">
        <h3>Share Page</h3>
        <div class="share-socials-bottom">
            <a href="https://www.facebook.com/sharer/sharer.php?u=http://www.themeforest.net/">
                <i class="fa fa-facebook facebook-color"></i>
                Facebook
            </a>
            <a href="https://twitter.com/home?status=Check%20out%20ThemeForest%20http://www.themeforest.net">
                <i class="fa fa-twitter twitter-color"></i>
                Twitter
            </a>
            <a href="https://plus.google.com/share?url=http://www.themeforest.net">
                <i class="fa fa-google-plus google-color"></i>
                Google
            </a>

            <a href="https://pinterest.com/pin/create/button/?url=http://www.themeforest.net/&media=https://0.s3.envato.com/files/63790821/profile-image.jpg&description=Themes%20and%20Templates">
                <i class="fa fa-pinterest-p pinterest-color"></i>
                Pinterest
            </a>
            <a href="sms:">
                <i class="fa fa-comment-o sms-color"></i>
                Text
            </a>
            <a href="mailto:?&subject=Check this page out!&body=http://www.themeforest.net">
                <i class="fa fa-envelope-o mail-color"></i>
                Email
            </a>
        </div>
        <a href="#" class="close-share-bottom">Close</a>
    </div>
    
</div>
    <script>
 

    $(function() {  
        $( "#awal" ).autocomplete({
         source: "datakotaawal.php",  
           minLength:2, 
        });
    });

    $(function() {  
        $( "#akhir" ).autocomplete({
         source: "datakotaawal.php",  
           minLength:2, 
        });
    });    
    </script>
</body>
</html>
